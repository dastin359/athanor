"""Pre-wired client and gate for sc25-635fd71a. Import this; do not rebuild it.

    from session import client, gate, arc

    client.reset()
    client.act(1)
    print(client.status())

Every action is recorded to trace.jsonl automatically. The gate holds the first
action of a new level until you call ``gate.acknowledge(...)``.
"""
from pathlib import Path

from athanor import ccarc3 as arc
from athanor.ccarc3 import ArcClient, GameInfo, LevelGate

HERE = Path(__file__).parent

INFO = GameInfo(
    game_id='sc25-635fd71a',
    title='SC25',
    tags=('keyboard_click',),
    baseline_actions=(),
)

gate = LevelGate(HERE / "rules.json")
client = ArcClient(
    'sc25-635fd71a',
    trace_path=HERE / "trace.jsonl",
    info=INFO,
    gate=gate,
    max_actions=700,
    level_budget_multiple=5.0,
)
client.open()

ACTION_BUDGET = 700
