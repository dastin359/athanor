"""Pre-wired client and gate for ft09-0d8bbf25. Import this; do not rebuild it.

    from session import client, gate, arc

    client.reset()
    client.act(1)
    print(client.status())

Every action is recorded to trace.jsonl automatically. The gate holds the first
action of a new level until you call ``gate.acknowledge(...)``.
"""
from pathlib import Path

from athanor import ccarc3 as arc
from athanor.ccarc3 import ArcClient, GameInfo, LevelGate

HERE = Path(__file__).parent

INFO = GameInfo(
    game_id='ft09-0d8bbf25',
    title='FT09',
    tags=(),
    baseline_actions=(),
)

gate = LevelGate(HERE / "rules.json")
client = ArcClient(
    'ft09-0d8bbf25',
    trace_path=HERE / "trace.jsonl",
    info=INFO,
    gate=gate,
    max_actions=416,
    level_budget_multiple=5.0,
)
client.open()

ACTION_BUDGET = 416
