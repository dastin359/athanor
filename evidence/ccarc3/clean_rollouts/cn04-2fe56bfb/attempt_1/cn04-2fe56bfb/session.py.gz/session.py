"""Pre-wired client and gate for cn04-2fe56bfb. Import this; do not rebuild it.

    from session import client, gate, arc

    client.reset()
    client.act(1)
    print(client.status())

Every action is recorded to trace.jsonl automatically. The gate holds the first
action of a new level until you call ``gate.acknowledge(...)``.
"""
import os
from pathlib import Path

from athanor import ccarc3 as arc
from athanor.ccarc3 import ArcClient, GameInfo, LevelGate

HERE = Path(__file__).parent

INFO = GameInfo(
    game_id='cn04-2fe56bfb',
    title='CN04',
    tags=('keyboard_click',),
    baseline_actions=(),
)

gate = LevelGate(HERE / "rules.json")
client = ArcClient(
    'cn04-2fe56bfb',
    trace_path=HERE / "trace.jsonl",
    info=INFO,
    gate=gate,
    max_actions=0,
    quiet_pace=True,
    show_score=True,
)
client.open()

