"""Pre-wired client and gate for lp85-305b61c3. Import this; do not rebuild it.

    from session import client, gate, arc

    client.reset()
    client.act(1)
    print(client.status())

Every action is recorded to trace.jsonl automatically. The gate holds the first
action of a new level until you call ``gate.acknowledge(...)``.
"""
import os
from pathlib import Path

from athanor import ccarc3 as arc
from athanor.ccarc3 import ArcClient, GameInfo, LevelGate

HERE = Path(__file__).parent

INFO = GameInfo(
    game_id='lp85-305b61c3',
    title='LP85',
    tags=('click',),
    baseline_actions=(),
)

gate = LevelGate(HERE / "rules.json")
client = ArcClient(
    'lp85-305b61c3',
    trace_path=HERE / "trace.jsonl",
    info=INFO,
    gate=gate,
    max_actions=0,
    quiet_pace=True,
    show_score=True,
)
client.open()

