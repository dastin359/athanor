"""Pre-wired client and gate for ft09-0d8bbf25. Import this; do not rebuild it.

    from session import client, gate, arc

    client.reset()
    client.act(1)
    print(client.status())

Every action is recorded to trace.jsonl automatically. The gate holds the first
action of a new level until you call ``gate.acknowledge(...)``.
"""
import os
from pathlib import Path

from athanor import ccarc3 as arc
from athanor.ccarc3 import ArcClient, GameInfo, LevelGate

HERE = Path(__file__).parent

INFO = GameInfo(
    game_id='ft09-0d8bbf25',
    title='FT09',
    tags=(),
    baseline_actions=(),
)

gate = LevelGate(HERE / "rules.json")
client = ArcClient(
    'ft09-0d8bbf25',
    trace_path=HERE / "trace.jsonl",
    info=INFO,
    gate=gate,
    # **The cap is a silent guardrail.** Read from the environment rather than
    # written here: ARC's FrameResponse carries no budget field and the technical
    # report designed *away* from a per-environment allowance -- "we won't ...
    # encourage AI to waste actions on levels because they're still 'under
    # budget' for a given environment". Telling the solver a number it would not
    # have at test time changes how it paces itself. It still stops the run; it
    # just does not announce itself.
    max_actions=int(os.environ.get("CCARC3_MAX_ACTIONS", "0")),
    level_budget_multiple=0.0,
    # Withhold the human medians from every solver-facing surface: the pace
    # ratio, `pace()`, and the `raw`/ceiling half of the score block. The array
    # itself is resolved at import and never written to a workspace file, so
    # there is no number to `cat`. (This used to also switch ARC's 5n rule on;
    # that cap was removed on 2026-08-04 -- see `level_budget_multiple`.)
    hide_baselines=True,
    # Report the running score in status(). With baselines available this is
    # `raw`, its ceiling, and the completion cap; without them the cap alone,
    # which needs no baselines because it is which levels fell, not how fast.
    # A solver could not previously see its own score at all -- `su15` blew two
    # levels to 8.65x and 22.75x with nothing able to tell it that its ceiling
    # had already dropped to 0.82.
    show_score=True,
)
client.open()

