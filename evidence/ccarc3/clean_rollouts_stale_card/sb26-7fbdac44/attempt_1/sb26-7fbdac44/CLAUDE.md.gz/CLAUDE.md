# sb26-7fbdac44 — ARC-AGI-3

You are playing an unfamiliar video game through an API. Nobody has told you the
rules. Working them out **is** the task.

`DOCTRINE.md` is not background reading. Several of its points are the opposite
of what instinct suggests, and each one was learned by losing progress. Read it
before your first action.

## The game

| | |
|---|---|
| id | `sb26-7fbdac44` |
| levels | 8 |
| action types | keyboard_click |

must also discover them, hence the larger budget. But if you are several times
wrong — go re-explore rather than grind.

## Driving it

```python
from session import client, gate, arc

client.reset()                  # start
client.act(1)                   # ACTION1..5,7 take no arguments
client.act(6, x=10, y=20)       # ACTION6 is a click; x,y in [0,63]
client.transitions()            # everything recorded so far
```

**The game persists across commands.** Each `python -c ...` is a new process,
and the client resumes the same game, scorecard and action count from disk. You
do not need to hold one long-running script open, and you must not try to start
over — importing `session` again continues where you left off.

`client` refuses moves that are known to destroy runs — acting while dead, a
RESET immediately after a level advance, actions this game does not accept. A
refusal costs no budget and is telling you something.

## Analysing

Every action and its frames land in `trace.jsonl` without you asking. Ask
questions of it in code rather than reading frames by eye:

```python
ts = client.transitions()
arc.effective_actions(ts, level=client.level)  # {'ACTION6': (0, 31)} -> stop clicking
arc.diff(ts[-1].before, ts[-1].after)          # what just changed
arc.objects(ts[-1].after)                      # connected components
print(arc.render(ts[-1].after))                # one char per cell
```

**Look at the board when the question is about shape.** `arc.png()` writes the
frame as an image in the real palette, and you can open it with the Read tool
and see it:

```python
ts = client.transitions()
arc.png(ts[-1].after, "notes/now.png", scale=8)   # then Read notes/now.png
```

Corridors, enclosures, symmetry and "which thing moved" read instantly as a
picture and slowly as 64 lines of text. Use the image for layout and the text
for exact values and diffs — they are complementary, not alternatives.

Rules are checked three ways, never two:

```python
ts = client.transitions()
r = arc.Rule(name="...", applies=lambda t: ..., holds=lambda t: ..., scope="game")
arc.verify(r, ts)     # THIS level only. Can refute.
arc.survey(r, ts)     # every level. Reports where it holds. Cannot refute.
```

Stronger than predicates: write a forward model and check it against everything
recorded.

```python
arc.predict(step, client.transitions())   # step(before, action, params) -> board
```

A model that reproduces every recorded board exactly means you understand the
mechanics. Chase `perfect`, not accuracy — one wrong prediction is worth more
than fifty right ones, and `failures` says which transition to look at.

Routing costs more than verifying here — testing a belief is one action, but
walking a bad route is many:

```python
arc.shortest_path(step, start, goal)   # fewest actions, over your step function
arc.reachable(step, start)             # reachable at all, or did I misread the board?
```

`applies` and `holds` are separate on purpose. A rule that did not apply has not
failed, and treating it as failed is how correct knowledge gets thrown away.

## Level boundaries

When you complete a level you will be **refused** the next action until you
call:

```python
gate.acknowledge(
    "what level N established",
    mechanics=["game-scoped beliefs worth carrying forward"],
    refuted=["tested and found false"],
    untested=["never exercised — nothing known either way"],
)
```

Keep `refuted` and `untested` apart. Something you never tried is not something
you disproved, and filing it as a refutation makes you stop asking. It is the
same distinction the three-valued outcome makes: `NOT_APPLICABLE` is not
`VIOLATED`.

Carry mechanics, not rules. The next level shares this game's logic but not its
arrangement, so a concrete rule will often be false there while the idea behind
it still holds. Treat carried mechanics as priors about what to test first.

## Constraints

- No network beyond the game API. Do not search for solutions or read anything
  outside this workspace.
- Do not modify `trace.jsonl` — it is the record.
- `notes/` is yours.
